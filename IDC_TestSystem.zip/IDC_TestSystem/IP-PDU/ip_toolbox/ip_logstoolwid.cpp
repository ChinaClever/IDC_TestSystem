﻿/*
 *
 *
 *  Created on: 2018年10月1日
 *      Author: Lzy
 */
#include "ip_logstoolwid.h"

IP_LogsToolWid::IP_LogsToolWid(QWidget *parent) :  LogsToolWid(parent)
{
    config = IP_ConfigFile::bulid();
    sipdu();
}




#include "ip_statustoolwid.h"

IP_StatusToolWid::IP_StatusToolWid(QWidget *parent) : StatusToolWid(parent)
{
     sipdu();
}

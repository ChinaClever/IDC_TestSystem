#ifndef IP_STATUSTOOLWID_H
#define IP_STATUSTOOLWID_H

#include "ip_settingtoolwid.h"

class IP_StatusToolWid : public StatusToolWid
{
    Q_OBJECT
public:
    explicit IP_StatusToolWid(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // IP_STATUSTOOLWID_H

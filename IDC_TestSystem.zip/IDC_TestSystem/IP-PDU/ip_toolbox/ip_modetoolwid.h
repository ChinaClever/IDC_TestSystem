#ifndef IP_MODETOOLWID_H
#define IP_MODETOOLWID_H

#include "ip_logstoolwid.h"

class IP_ModeToolWid : public ModeToolWid
{
    Q_OBJECT
public:
    explicit IP_ModeToolWid(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // IP_MODETOOLWID_H

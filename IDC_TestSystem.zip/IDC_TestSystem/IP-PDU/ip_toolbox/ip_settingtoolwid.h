#ifndef IP_SETTINGTOOLWID_H
#define IP_SETTINGTOOLWID_H

#include "ip_modetoolwid.h"


class IP_SettingToolWid : public SettingToolWid
{
    Q_OBJECT

public:
    explicit IP_SettingToolWid(QWidget *parent = 0);
};

#endif // IP_SETTINGTOOLWID_H

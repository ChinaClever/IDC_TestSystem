/*
 *
 *
 *  Created on: 2018年10月1日
 *      Author: Lzy
 */
#include "ip_dpsaverecord.h"
#include "ip_sql/ipdbrealrecords.h"

IP_DpSaveRecord::IP_DpSaveRecord(QObject *parent) : DpSaveLine(parent)
{

}

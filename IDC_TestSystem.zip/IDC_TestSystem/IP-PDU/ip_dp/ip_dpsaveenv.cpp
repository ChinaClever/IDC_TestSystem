/*
 *
 *
 *  Created on: 2018年10月1日
 *      Author: Lzy
 */
#include "ip_dpsaveenv.h"


IP_DpSaveEnv::IP_DpSaveEnv(QObject *parent) : DpSaveEnv(parent)
{

}

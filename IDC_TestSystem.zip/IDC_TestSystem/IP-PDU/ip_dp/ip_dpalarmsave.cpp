/*
 *
 *
 *  Created on: 2018年10月1日
 *      Author: Lzy
 */
#include "ip_dpalarmsave.h"


IP_DpAlarmSave::IP_DpAlarmSave(QObject *parent) : DpAlarmSave(parent)
{

}



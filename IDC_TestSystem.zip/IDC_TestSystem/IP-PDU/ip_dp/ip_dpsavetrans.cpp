/*
 *
 *
 *  Created on: 2018年10月1日
 *      Author: Lzy
 */
#include "ip_dpsavetrans.h"
#include "ip_sql/ipdbmodbustrans.h"

IP_DpSaveTrans::IP_DpSaveTrans(QObject *parent) : DpSaveTrans(parent)
{

}


/*
 *
 *
 *  Created on: 2018年10月1日
 *      Author: Lzy
 */
#include "ip_dpsavethreshold.h"

IP_DpSaveThreshold::IP_DpSaveThreshold(QObject *parent) : DpSaveLineThreshold(parent)
{

}



#ifndef M_SETTINGTOOLWID_H
#define M_SETTINGTOOLWID_H

#include "m_logstoolwid.h"

class M_SettingToolWid : public SettingToolWid
{
    Q_OBJECT

public:
    explicit M_SettingToolWid(QWidget *parent = 0);
};

#endif // M_SETTINGTOOLWID_H

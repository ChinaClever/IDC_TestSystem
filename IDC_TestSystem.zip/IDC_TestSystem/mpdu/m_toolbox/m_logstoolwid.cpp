﻿/*
 *
 *
 *  Created on: 2018年10月1日
 *      Author: Lzy
 */
#include "m_logstoolwid.h"

M_LogsToolWid::M_LogsToolWid(QWidget *parent) : LogsToolWid(parent)
{
    config = M_ConfigFile::bulid();
    mpdu();
}

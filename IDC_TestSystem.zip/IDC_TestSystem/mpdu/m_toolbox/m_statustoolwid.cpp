/*
 *
 *
 *  Created on: 2018年10月1日
 *      Author: Lzy
 */
#include "m_statustoolwid.h"

M_StatusToolWid::M_StatusToolWid(QWidget *parent) : StatusToolWid(parent)
{
    mpdu();
}


#ifndef M_MODETOOLWID_H
#define M_MODETOOLWID_H

#include "m_statustoolwid.h"

class M_ModeToolWid : public ModeToolWid
{
    Q_OBJECT
public:
    explicit M_ModeToolWid(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // M_MODETOOLWID_H

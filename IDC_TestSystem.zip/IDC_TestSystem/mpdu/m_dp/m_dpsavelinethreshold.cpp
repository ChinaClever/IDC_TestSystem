/*
 *
 *
 *  Created on: 2018年10月1日
 *      Author: Lzy
 */
#include "m_dpsavelinethreshold.h"

M_DpSaveLineThreshold::M_DpSaveLineThreshold(QObject *parent) : DpSaveLineThreshold(parent)
{

}

/*
 *
 *
 *  Created on: 2018年10月1日
 *      Author: Lzy
 */
#include "m_dpsavelinerecord.h"

M_DpSaveLineRecord::M_DpSaveLineRecord(QObject *parent) : DpSaveLine(parent)
{

}

/*
 *
 *
 *  Created on: 2018年10月1日
 *      Author: Lzy
 */
#include "m_dpsavetrans.h"

M_DpSaveTrans::M_DpSaveTrans(QObject *parent) : DpSaveTrans(parent)
{

}

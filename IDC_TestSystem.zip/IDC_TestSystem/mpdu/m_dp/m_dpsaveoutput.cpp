/*
 *
 *
 *  Created on: 2018年10月1日
 *      Author: Lzy
 */
#include "m_dpsaveoutput.h"

M_DpSaveOutput::M_DpSaveOutput(QObject *parent) : DpSaveOutput(parent)
{

}

/*
 *
 *
 *  Created on: 2018年10月1日
 *      Author: Lzy
 */
#include "m_dpalarmsave.h"

M_DpAlarmSave::M_DpAlarmSave(QObject *parent) : DpAlarmSave(parent)
{

}

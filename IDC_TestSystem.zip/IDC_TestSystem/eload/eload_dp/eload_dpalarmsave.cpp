#include "eload_dpalarmsave.h"

ELoad_DpAlarmSave::ELoad_DpAlarmSave(QObject *parent) : DpAlarmSave(parent)
{

}

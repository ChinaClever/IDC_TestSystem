#include "eload_dpsavetrans.h"

ELoad_DpSaveTrans::ELoad_DpSaveTrans(QObject *parent) : DpSaveTrans(parent)
{

}

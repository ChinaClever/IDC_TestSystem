#include "eload_dpsaveenv.h"

ELoad_DpSaveEnv::ELoad_DpSaveEnv(QObject *parent) : DpSaveEnv(parent)
{

}

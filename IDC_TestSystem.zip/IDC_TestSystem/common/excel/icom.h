﻿#ifndef ICOM_H
#define ICOM_H

//#include "icom_global.h"

#include <QString>
#include <QtCore>

class Q_DECL_IMPORT Icom
{

public:
    Icom();
};

#endif // ICOM_H

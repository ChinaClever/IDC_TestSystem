#ifndef ICOM_H
#define ICOM_H

#include "icom_global.h"

class ICOMSHARED_EXPORT Icom
{

public:
    Icom();
};

#endif // ICOM_H
                                                  
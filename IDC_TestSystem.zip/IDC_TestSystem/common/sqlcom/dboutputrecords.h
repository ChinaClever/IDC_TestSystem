#ifndef DBOUTPUTRECORDS_H
#define DBOUTPUTRECORDS_H
#include "dblinerecords.h"

typedef DbLineRecordItem DbOutputItem;


class DbOutputRecords : public DbLineRecords
{
public:
    DbOutputRecords();
};

#endif // DBOUTPUTRECORDS_H

#include "dboutputrecords.h"

DbOutputRecords::DbOutputRecords()
{

}

#ifndef DBLOOPRECORDS_H
#define DBLOOPRECORDS_H
#include "dblinerecords.h"

typedef DbLineRecordItem DbLoopItem;

class DbLoopRecords : public DbLineRecords
{
public:
    DbLoopRecords();
};

#endif // DBLOOPRECORDS_H
